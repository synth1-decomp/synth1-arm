flat bank readme
